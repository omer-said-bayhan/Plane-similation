/* global THREE */
"use strict";

// ─────────────────────────────────────────────
//  DOM
// ─────────────────────────────────────────────
const canvas      = document.querySelector("#c");
const elSpeed     = document.querySelector("#speed");
const elAlt       = document.querySelector("#altitude");
const elPitch     = document.querySelector("#pitch");
const elHeading   = document.querySelector("#heading");
const elG         = document.querySelector("#gforce");
const elWind      = document.querySelector("#wind");
const elAoA       = document.querySelector("#aoa");
const elDynPress  = document.querySelector("#dynpress");
const elStress    = document.querySelector("#stress");
const elGWarn     = document.querySelector("#g-warn");
const elCrash     = document.querySelector("#crash-msg");
const elMach      = document.getElementById("mach");
const elThrottle  = document.getElementById("throttle");
const elRoll      = document.getElementById("roll");

// ─────────────────────────────────────────────
//  WORLD CONSTANTS
// ─────────────────────────────────────────────
const WORLD        = 80000;
const GROUND_Y     = 0;

// ─────────────────────────────────────────────
//  PHYSICS CONSTANTS  (realistic F-22 envelope)
// ─────────────────────────────────────────────
const GRAVITY        = 9.80665;      // m/s²
const RHO0           = 1.225;        // kg/m³ sea-level density
const SCALE_ALT      = 8500;         // density scale height (m)
const SPEED_OF_SOUND = 340.29;       // m/s at sea level

// F-22 aerodynamic params
const WING_AREA      = 78.0;         // m²
const AIRCRAFT_MASS  = 19700;        // kg (combat weight)
const CL_ALPHA       = 4.8;          // lift curve slope (per rad)
const CD0            = 0.016;        // zero-lift drag coefficient
const K_IND          = 0.13;         // induced drag factor (1/πARe)
const CL_MAX         = 1.65;         // max lift coefficient (before stall)
const AOA_STALL_RAD  = 0.38;         // stall AoA ≈ 22°
const AOA_CRIT_RAD   = 0.55;         // structural AoA limit ≈ 31°

// F-22 Raptor dual F119 engines: ~311 kN total thrust (AB), ~156 kN dry
const THRUST_MAX_AB  = 311000;       // N (afterburner)
const THRUST_MAX_DRY = 156000;       // N (dry)
const THRUST_MIN     = 6000;         // N (idle)

// Control limits
const PITCH_RATE     = 1.4;          // rad/s max pitch rate
const ROLL_RATE      = 3.0;          // rad/s max roll rate (F-22 is extremely agile)
const YAW_RATE       = 0.35;         // rad/s max yaw rate
const SIDESLIP_DAMP  = 2.2;          // sideslip damping factor

// Structural limits
const G_LIMIT_POS    = 9.0;          // +G limit
const G_LIMIT_NEG    = -3.0;         // -G limit
const Q_LIMIT_PA     = 120000;       // dynamic pressure limit (Pa)
const AOA_BREAK_DEG  = 36;
const G_WARN         = 7.2;
const G_STRESS_SOFT  = 7.8;
const G_STRESS_HARD  = 9.0;
const STRESS_DECAY   = 28;
const STRESS_BUILD_S = 6;
const STRESS_BUILD_H = 22;
const PLANE_CLEARANCE= 11;
const PLANE_HIT_HALF = 14;

// Camera
const ORBIT_ROT_SENS = 0.0042;

// ─────────────────────────────────────────────
//  INPUT STATE
// ─────────────────────────────────────────────
const keys = { w:false, s:false, a:false, d:false, ArrowUp:false, ArrowDown:false, q:false, e:false };

window.addEventListener("keydown", e => {
  const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
  if (k in keys) { keys[k] = true; e.preventDefault(); }
  if (e.code === "KeyF") respawnAtNearestRunway();
});
window.addEventListener("keyup", e => {
  const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
  if (k in keys) keys[k] = false;
});

// ─────────────────────────────────────────────
//  CAMERA ORBIT
// ─────────────────────────────────────────────
let orbitTheta = 0.55, orbitPhi = Math.PI * 0.38, orbitRadius = 155;
let mouseDragActive = false;

canvas.addEventListener("mousedown", e => {
  if (e.button === 0) canvas.requestPointerLock();
  if (e.button === 2 || e.button === 1) mouseDragActive = true;
});
canvas.addEventListener("mouseup", () => { mouseDragActive = false; });
canvas.addEventListener("contextmenu", e => e.preventDefault());

document.addEventListener("mousemove", e => {
  const locked = document.pointerLockElement === canvas;
  if (locked || mouseDragActive) {
    const s = locked ? ORBIT_ROT_SENS : ORBIT_ROT_SENS * 0.85;
    orbitTheta -= e.movementX * s;
    orbitPhi   -= e.movementY * s;
    orbitPhi    = THREE.MathUtils.clamp(orbitPhi, 0.012, Math.PI - 0.012);
  }
});
canvas.addEventListener("wheel", e => {
  e.preventDefault();
  orbitRadius += e.deltaY * 0.14;
  orbitRadius  = THREE.MathUtils.clamp(orbitRadius, 30, 500);
}, { passive: false });

// ─────────────────────────────────────────────
//  ATMOSPHERE MODEL (ISA)
// ─────────────────────────────────────────────
function airDensity(alt) {
  const h = Math.max(0, alt);
  if (h < 11000) {
    // troposphere
    const T = 288.15 - 0.0065 * h;
    return 1.225 * Math.pow(T / 288.15, 4.256);
  } else {
    // stratosphere
    return 0.3639 * Math.exp(-(h - 11000) / 6341.6);
  }
}

function speedOfSound(alt) {
  const h = Math.max(0, alt);
  if (h < 11000) {
    const T = 288.15 - 0.0065 * h;
    return 331.3 * Math.sqrt(T / 273.15);
  }
  return 295.0; // constant in stratosphere
}

// ─────────────────────────────────────────────
//  TERRAIN
// ─────────────────────────────────────────────
const HILLS    = [];
const RUNWAYS  = [];
const COLLIDERS= [];

function terrainHeight(x, z) {
  let h = GROUND_Y;
  for (const hill of HILLS) {
    const d = Math.hypot(x - hill.x, z - hill.z);
    if (d < hill.r) {
      const t = 1 - d / hill.r;
      const coneH = hill.h * t * t; // smoother cone
      if (coneH > h) h = coneH;
    }
  }
  return h;
}

function pointOnRunway(px, py, pz) {
  for (const rw of RUNWAYS) {
    const dx = px - rw.cx, dz = pz - rw.cz;
    const c = Math.cos(-rw.yaw), s = Math.sin(-rw.yaw);
    const lx = dx * c - dz * s, lz = dx * s + dz * c;
    const th = terrainHeight(px, pz);
    if (Math.abs(lx) < rw.halfW - 2 && Math.abs(lz) < rw.halfL - 2 && py < th + 28) return true;
  }
  return false;
}

function xzNearRunway(px, pz, expand = 110) {
  for (const rw of RUNWAYS) {
    const dx = px - rw.cx, dz = pz - rw.cz;
    const c = Math.cos(-rw.yaw), s = Math.sin(-rw.yaw);
    const lx = dx * c - dz * s, lz = dx * s + dz * c;
    if (Math.abs(lx) < rw.halfW + expand && Math.abs(lz) < rw.halfL + expand) return true;
  }
  return false;
}

function boxHit(px, py, pz) {
  const r2 = PLANE_HIT_HALF * PLANE_HIT_HALF;
  for (const b of COLLIDERS) {
    const cx = THREE.MathUtils.clamp(px, b.minX, b.maxX);
    const cy = THREE.MathUtils.clamp(py, b.minY, b.maxY);
    const cz = THREE.MathUtils.clamp(pz, b.minZ, b.maxZ);
    const dx = px-cx, dy = py-cy, dz = pz-cz;
    if (dx*dx+dy*dy+dz*dz < r2) return true;
  }
  return false;
}

// ─────────────────────────────────────────────
//  F-22 RAPTOR 3D MODEL  (accurate silhouette)
// ─────────────────────────────────────────────
function buildF22() {
  const group = new THREE.Group();
  const S = 1.0; // scale unit

  // ── Materials ──────────────────────────────
  const matBody   = new THREE.MeshStandardMaterial({ color:0x5a6570, metalness:0.75, roughness:0.30 });
  const matDark   = new THREE.MeshStandardMaterial({ color:0x2a3038, metalness:0.65, roughness:0.45 });
  const matVentral= new THREE.MeshStandardMaterial({ color:0x8a9299, metalness:0.55, roughness:0.40 });
  const matCanopy = new THREE.MeshStandardMaterial({ color:0x2a5f8a, metalness:0.95, roughness:0.05, transparent:true, opacity:0.72, envMapIntensity:1.2 });
  const matNoz    = new THREE.MeshStandardMaterial({ color:0x1a1e22, metalness:0.95, roughness:0.15, emissive:0xff3000, emissiveIntensity:0 });
  const matGlow   = new THREE.MeshBasicMaterial({ color:0xff5500, transparent:true, opacity:0, depthWrite:false, side:THREE.DoubleSide });
  const matVapor  = new THREE.MeshBasicMaterial({ color:0xffffff, transparent:true, opacity:0, depthWrite:false, side:THREE.DoubleSide });
  const matRed    = new THREE.MeshBasicMaterial({ color:0xff0000 });
  const matGreen  = new THREE.MeshBasicMaterial({ color:0x00ff88 });

  function add(m) { group.add(m); return m; }

  // ── 1. FUSELAGE — smooth blended body ──────
  // F-22 has a distinctive diamond-cross-section chined fuselage
  // We build it with a series of cross-sections extruded via TubeGeometry path
  const path = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0,  0.1, -19*S),  // nose tip
    new THREE.Vector3(0,  0.2, -16*S),
    new THREE.Vector3(0,  0.6, -12*S),  // cockpit area
    new THREE.Vector3(0,  0.6,  -6*S),
    new THREE.Vector3(0,  0.3,   2*S),  // widest at wing root
    new THREE.Vector3(0,  0.1,  10*S),  // aft fuselage
    new THREE.Vector3(0, -0.1,  15*S),  // nozzle area
    new THREE.Vector3(0, -0.2,  18*S),  // tail end
  ]);

  // Build fuselage as a sequence of merged box/cylinder volumes
  // Upper fuselage ridge
  const fuseUpper = new THREE.Mesh(
    new THREE.CylinderGeometry(0, 0, 1, 4, 1).applyMatrix4(new THREE.Matrix4()), // placeholder
    matBody
  );

  // --- Main chined fuselage body ---
  // Use a custom shape swept along the path
  const fuseShape = new THREE.Shape();
  fuseShape.moveTo(0, 1.2*S);        // top center
  fuseShape.lineTo(2.1*S, 0.4*S);    // right chine
  fuseShape.lineTo(1.8*S, -0.8*S);   // right lower
  fuseShape.lineTo(0, -1.1*S);       // bottom
  fuseShape.lineTo(-1.8*S, -0.8*S);
  fuseShape.lineTo(-2.1*S, 0.4*S);
  fuseShape.closePath();

  const extSettings = {
    steps: 24,
    bevelEnabled: false,
    extrudePath: path,
  };
  const fuseGeo = new THREE.ExtrudeGeometry(fuseShape, extSettings);
  fuseGeo.computeVertexNormals();
  const fuse = add(new THREE.Mesh(fuseGeo, matBody));
  fuse.rotation.y = Math.PI; // nose forward (-Z)

  // ── 2. DELTA WINGS (cranked-arrow planform) ─
  // Real F-22 wing: 42° leading-edge sweep inner, more outboard
  const wingShapeR = new THREE.Shape();
  wingShapeR.moveTo(0, 0);           // wing root LE (at fuselage)
  wingShapeR.lineTo(0, -3.5*S);      // forward strake
  wingShapeR.lineTo(10.5*S, 2.0*S);  // wingtip LE
  wingShapeR.lineTo(10.3*S, 4.5*S);  // wingtip TE
  wingShapeR.lineTo(1.5*S, 7.5*S);   // wing root TE
  wingShapeR.closePath();

  const wingGeoR = new THREE.ExtrudeGeometry(wingShapeR, {
    depth: 0.18*S, bevelEnabled:true, bevelSize:0.12*S, bevelThickness:0.1*S, bevelSegments:2
  });
  const wingR = add(new THREE.Mesh(wingGeoR, matBody));
  wingR.position.set(1.8*S, -0.3*S, -5.5*S);
  wingR.rotation.x = Math.PI / 2;

  const wingL = wingR.clone();
  wingL.scale.x = -1;
  add(wingL);

  // ── 3. HORIZONTAL STABILATORS (all-moving) ─
  const stabShape = new THREE.Shape();
  stabShape.moveTo(0, 0);
  stabShape.lineTo(0, -1.5*S);
  stabShape.lineTo(5.8*S, 1.0*S);
  stabShape.lineTo(5.6*S, 3.2*S);
  stabShape.lineTo(0.8*S, 3.4*S);
  stabShape.closePath();

  const stabGeo = new THREE.ExtrudeGeometry(stabShape, {
    depth:0.12*S, bevelEnabled:true, bevelSize:0.08*S, bevelThickness:0.08*S, bevelSegments:2
  });

  const stabR = new THREE.Object3D();
  stabR.position.set(1.6*S, -0.4*S, 8.5*S);
  const stabMeshR = new THREE.Mesh(stabGeo, matBody);
  stabMeshR.rotation.x = Math.PI/2;
  stabR.add(stabMeshR);
  add(stabR);

  const stabL = new THREE.Object3D();
  stabL.position.set(-1.6*S, -0.4*S, 8.5*S);
  const stabMeshL = new THREE.Mesh(stabGeo, matBody);
  stabMeshL.rotation.x = Math.PI/2;
  stabMeshL.scale.x = -1;
  stabL.add(stabMeshL);
  add(stabL);

  // ── 4. CANTED VERTICAL TAILS (27° outward cant) ─
  const vtShape = new THREE.Shape();
  vtShape.moveTo(0, 0);
  vtShape.lineTo(0.8*S, 0);
  vtShape.lineTo(-1.6*S, 5.5*S);
  vtShape.lineTo(-3.2*S, 5.4*S);
  vtShape.lineTo(-2.8*S, 0.1*S);
  vtShape.closePath();

  const vtGeo = new THREE.ExtrudeGeometry(vtShape, {
    depth:0.14*S, bevelEnabled:true, bevelSize:0.06*S, bevelThickness:0.07*S, bevelSegments:2
  });

  for (let si = -1; si <= 1; si += 2) {
    const vt = add(new THREE.Mesh(vtGeo, matBody));
    vt.position.set(si * 1.4*S, 0.3*S, 8.2*S);
    // 27° cant outward + sweep back
    vt.rotation.set(-0.08, si * 0.08, si * 0.47);
    if (si < 0) vt.scale.x = -1;
  }

  // ── 5. DSI INTAKES (diverterless supersonic) ─
  // Distinctive F-22 feature: raised bump intakes
  for (let si = -1; si <= 1; si += 2) {
    const intakeGroup = new THREE.Group();
    // Main intake duct
    const intakeDuct = new THREE.Mesh(
      new THREE.BoxGeometry(2.2*S, 1.3*S, 6.5*S),
      matDark
    );
    intakeDuct.position.set(0, 0.1*S, 0);
    intakeGroup.add(intakeDuct);

    // Bump (diverter)
    const bump = new THREE.Mesh(
      new THREE.SphereGeometry(1.0*S, 12, 8),
      matVentral
    );
    bump.scale.set(1.0, 0.4, 1.8);
    bump.position.set(0, 0.55*S, -1.0*S);
    intakeGroup.add(bump);

    intakeGroup.position.set(si * 2.4*S, -0.5*S, -5.0*S);
    add(intakeGroup);
  }

  // ── 6. COCKPIT / CANOPY ───────────────────
  // Distinctive F-22 bubble canopy
  const canopyBase = new THREE.Mesh(
    new THREE.SphereGeometry(1.5*S, 24, 18),
    matCanopy
  );
  canopyBase.scale.set(0.72, 0.52, 2.1);
  canopyBase.position.set(0, 1.05*S, -11.5*S);
  add(canopyBase);

  // Canopy frame lines (structural appearance)
  const frameMat = new THREE.MeshStandardMaterial({ color:0x1a1e22, metalness:0.9, roughness:0.2 });
  const frameBar = new THREE.Mesh(
    new THREE.BoxGeometry(0.08*S, 0.08*S, 3.0*S),
    frameMat
  );
  frameBar.position.copy(canopyBase.position);
  frameBar.position.y += 0.7*S;
  add(frameBar);

  // ── 7. TVC NOZZLES (2D thrust-vectoring) ──
  const nozzleRefs = [], glowRefs = [];
  for (let si = -1; si <= 1; si += 2) {
    // Nozzle box — 2D rectangular
    const nozOuter = new THREE.Mesh(
      new THREE.BoxGeometry(2.0*S, 1.0*S, 2.2*S),
      matDark
    );
    nozOuter.position.set(si * 1.2*S, -0.05*S, 16.5*S);
    add(nozOuter);

    // Inner nozzle plates
    const nozInner = new THREE.Mesh(
      new THREE.BoxGeometry(1.6*S, 0.7*S, 0.3*S),
      matNoz.clone()
    );
    nozInner.position.set(si * 1.2*S, -0.05*S, 17.5*S);
    add(nozInner);
    nozzleRefs.push(nozInner);

    // AB glow disk
    const g1 = new THREE.Mesh(
      new THREE.PlaneGeometry(1.4*S, 0.8*S),
      matGlow.clone()
    );
    g1.position.set(si * 1.2*S, -0.05*S, 17.8*S);
    add(g1);
    glowRefs.push(g1);

    // Outer AB cone glow
    const g2 = new THREE.Mesh(
      new THREE.PlaneGeometry(2.0*S, 1.2*S),
      new THREE.MeshBasicMaterial({ color:0xff8800, transparent:true, opacity:0, depthWrite:false, side:THREE.DoubleSide })
    );
    g2.position.set(si * 1.2*S, -0.05*S, 19.5*S);
    add(g2);
    glowRefs.push(g2);
  }

  // ── 8. NAVIGATION LIGHTS ──────────────────
  // Red (port/left wingtip)
  const navL = add(new THREE.Mesh(new THREE.SphereGeometry(0.18*S, 8, 6), matRed));
  navL.position.set(-10.5*S, 0.3*S, 2.0*S);
  // Green (starboard/right wingtip)
  const navR = add(new THREE.Mesh(new THREE.SphereGeometry(0.18*S, 8, 6), matGreen));
  navR.position.set(10.5*S, 0.3*S, 2.0*S);

  // ── 9. WING VAPOR TRAILS ─────────────────
  const vaporRefs = [];
  const vGeo = new THREE.PlaneGeometry(12*S, 10*S);
  for (const [x, y, z] of [[-10*S, 0.2*S, 4*S], [10*S, 0.2*S, 4*S], [0, 1.0*S, -10*S]]) {
    const vm = new THREE.Mesh(vGeo, matVapor.clone());
    vm.position.set(x, y, z);
    vm.rotation.x = -Math.PI / 2;
    add(vm);
    vaporRefs.push(vm);
  }

  // ── 10. FINALIZE ─────────────────────────
  group.rotation.order = "YXZ";
  group.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });

  group.userData = {
    vapor  : vaporRefs,
    nozzles: nozzleRefs,
    glows  : glowRefs,
    ctrl   : { stabL, stabR },
  };

  return group;
}

// ─────────────────────────────────────────────
//  WORLD BUILDING
// ─────────────────────────────────────────────
function buildWorld(scene) {
  // ── Ground with vertex-color elevation ──
  const gRes = 128;
  const gGeo = new THREE.PlaneGeometry(WORLD, WORLD, gRes, gRes);
  gGeo.rotateX(-Math.PI / 2);

  // Apply height to vertices + color by height
  const pos = gGeo.attributes.position;
  const col = new Float32Array(pos.count * 3);

  // Pre-generate hills first so we can query them
  for (let i = 0; i < 480; i++) {
    HILLS.push({
      x: (Math.random()-0.5)*WORLD*0.9,
      z: (Math.random()-0.5)*WORLD*0.9,
      r: 200 + Math.random()*2800,
      h: 40  + Math.random()*920,
    });
  }

  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i);
    const h = terrainHeight(x, z);
    pos.setY(i, h);

    // Color gradient: deep green → rock → snow by altitude
    let r,g,b;
    if (h < 5) {
      r=0.18; g=0.30; b=0.14; // lowland grass
    } else if (h < 180) {
      const t=(h-5)/175;
      r=0.18+t*0.14; g=0.30-t*0.06; b=0.14+t*0.05;
    } else if (h < 450) {
      const t=(h-180)/270;
      r=0.32+t*0.25; g=0.24-t*0.10; b=0.19+t*0.05;
    } else if (h < 700) {
      const t=(h-450)/250;
      r=0.57+t*0.22; g=0.14+t*0.12; b=0.24+t*0.10;
    } else {
      const t=Math.min(1,(h-700)/200);
      r=0.79+t*0.21; g=0.26+t*0.74; b=0.34+t*0.66;
    }
    col[i*3]=r; col[i*3+1]=g; col[i*3+2]=b;
  }
  gGeo.setAttribute("color", new THREE.BufferAttribute(col, 3));
  gGeo.computeVertexNormals();

  const gMat = new THREE.MeshStandardMaterial({
    vertexColors: true, metalness:0.05, roughness:0.88,
  });
  const ground = new THREE.Mesh(gGeo, gMat);
  ground.receiveShadow = true;
  scene.add(ground);

  // ── Water plane (low-lying areas) ────────
  const waterGeo = new THREE.PlaneGeometry(WORLD, WORLD);
  const waterMat = new THREE.MeshStandardMaterial({
    color:0x1a4a7a, metalness:0.8, roughness:0.1, transparent:true, opacity:0.78
  });
  const water = new THREE.Mesh(waterGeo, waterMat);
  water.rotation.x = -Math.PI/2;
  water.position.y = 1.5;
  scene.add(water);

  // ── Runways ───────────────────────────────
  const rwMat = new THREE.MeshStandardMaterial({ color:0x1a1c1e, metalness:0.08, roughness:0.85 });
  const stripeMat = new THREE.MeshStandardMaterial({ color:0xffffff, metalness:0.0, roughness:0.9 });

  for (let i = 0; i < 8; i++) {
    const cx = (Math.random()-0.5)*38000;
    const cz = (Math.random()-0.5)*38000;
    const halfW=44, halfL=600;
    const yaw = Math.random()*Math.PI;
    const ty = terrainHeight(cx, cz);

    const rw = new THREE.Mesh(new THREE.PlaneGeometry(halfW*2, halfL*2), rwMat);
    rw.rotation.x = -Math.PI/2; rw.rotation.z = -yaw;
    rw.position.set(cx, ty+0.25, cz);
    rw.receiveShadow = true;
    scene.add(rw);

    // Center-line stripes
    for (let j = -5; j <= 5; j++) {
      const stripe = new THREE.Mesh(new THREE.PlaneGeometry(2.5, 40), stripeMat);
      stripe.rotation.x = -Math.PI/2; stripe.rotation.z = -yaw;
      const along = j * 90;
      stripe.position.set(
        cx + Math.sin(yaw)*along,
        ty+0.35,
        cz + Math.cos(yaw)*along
      );
      scene.add(stripe);
    }

    // Threshold markings
    for (let side = -1; side <= 1; side += 2) {
      const thresh = new THREE.Mesh(new THREE.PlaneGeometry(halfW*2-4, 8), stripeMat);
      thresh.rotation.x = -Math.PI/2; thresh.rotation.z = -yaw;
      thresh.position.set(
        cx + Math.sin(yaw)*side*(halfL-20),
        ty+0.35,
        cz + Math.cos(yaw)*side*(halfL-20)
      );
      scene.add(thresh);
    }

    RUNWAYS.push({ cx, cz, halfW, halfL, yaw });
  }

  // ── Buildings (cities / military base) ───
  const bMat = new THREE.MeshStandardMaterial({ color:0x6a7078, metalness:0.2, roughness:0.75 });
  const bGeo = new THREE.BoxGeometry(1,1,1);

  for (let i = 0; i < 700; i++) {
    const cx = (Math.random()-0.5)*52000;
    const cz = (Math.random()-0.5)*52000;
    if (xzNearRunway(cx, cz)) continue;
    const ty = terrainHeight(cx, cz);
    if (ty > 300) continue; // no buildings on mountain tops
    const hw=10+Math.random()*28, hh=14+Math.random()*80, hd=10+Math.random()*28;
    const m = new THREE.Mesh(bGeo, bMat);
    m.scale.set(hw*2, hh*2, hd*2);
    m.position.set(cx, ty+hh, cz);
    m.castShadow = m.receiveShadow = true;
    scene.add(m);
    COLLIDERS.push({ minX:cx-hw, maxX:cx+hw, minY:ty, maxY:ty+hh*2, minZ:cz-hd, maxZ:cz+hd });
  }

  // ── Volumetric cloud layer ────────────────
  const cloudMat = new THREE.MeshStandardMaterial({
    color:0xffffff, transparent:true, opacity:0.72,
    metalness:0, roughness:1.0, depthWrite:false,
  });
  const cGeo = new THREE.SphereGeometry(1, 7, 5);
  for (let i = 0; i < 220; i++) {
    const cg = new THREE.Group();
    const cx = (Math.random()-0.5)*WORLD*0.8;
    const cz = (Math.random()-0.5)*WORLD*0.8;
    const cy = 1800 + Math.random()*2200;
    const nr = 4 + Math.floor(Math.random()*6);
    for (let j = 0; j < nr; j++) {
      const cm = new THREE.Mesh(cGeo, cloudMat);
      const rx = (Math.random()-0.5)*600, rz = (Math.random()-0.5)*400;
      const rs = 100+Math.random()*350;
      cm.position.set(rx, (Math.random()-0.5)*60, rz);
      cm.scale.setScalar(rs);
      cm.castShadow = false;
      cg.add(cm);
    }
    cg.position.set(cx, cy, cz);
    scene.add(cg);
  }
}

// ─────────────────────────────────────────────
//  SCENE SETUP
// ─────────────────────────────────────────────
const scene = new THREE.Scene();

// Sky gradient — deeper blue at top, horizon haze
scene.background = new THREE.Color(0x4a90d9);

// Layered fog — realistic atmospheric depth
scene.fog = new THREE.FogExp2(0x9bbde0, 0.000038);

const camera = new THREE.PerspectiveCamera(55, innerWidth/innerHeight, 0.5, 150000);
camera.position.set(0, 250, 600);

// ── Lighting ─────────────────────────────────
// Sun (directional, golden afternoon)
const sun = new THREE.DirectionalLight(0xfff4d0, 1.45);
sun.position.set(6000, 12000, 3000);
sun.castShadow = true;
sun.shadow.mapSize.set(4096, 4096);
sun.shadow.camera.near = 100;
sun.shadow.camera.far  = 35000;
const sc = 18000;
sun.shadow.camera.left   = -sc;
sun.shadow.camera.right  =  sc;
sun.shadow.camera.top    =  sc;
sun.shadow.camera.bottom = -sc;
sun.shadow.bias = -0.0003;
scene.add(sun);

// Sky hemisphere (sky↔ground ambient)
const hemi = new THREE.HemisphereLight(0x7ec8ff, 0x3a5c32, 0.75);
scene.add(hemi);

// Subtle fill light (bounce from ground)
const fill = new THREE.DirectionalLight(0x88bbdd, 0.28);
fill.position.set(-3000, 500, -4000);
scene.add(fill);

// ── Renderer ─────────────────────────────────
const renderer = new THREE.WebGLRenderer({ canvas, antialias:true, powerPreference:"high-performance" });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2.5));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type    = THREE.PCFSoftShadowMap;
renderer.toneMapping       = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.12;
renderer.outputColorSpace  = THREE.SRGBColorSpace || "srgb";

// ── Aircraft ──────────────────────────────────
const plane = buildF22();
plane.position.set(0, 550, 0);
scene.add(plane);

buildWorld(scene);

// ─────────────────────────────────────────────
//  FLIGHT STATE
// ─────────────────────────────────────────────
const WIND        = new THREE.Vector3(8, 0.3, -7);   // m/s ambient wind
const velocity    = new THREE.Vector3(0, 0, -110);   // initial airspeed m/s (~400 km/h)

// Vectors (reused)
const tmpFwd   = new THREE.Vector3();
const noseDir  = new THREE.Vector3();
const camPos   = new THREE.Vector3();
const accel    = new THREE.Vector3();
const relWind  = new THREE.Vector3();
const relN     = new THREE.Vector3();
const prevVel  = new THREE.Vector3();
const liftDir  = new THREE.Vector3();
const sideDir  = new THREE.Vector3();
const upDir    = new THREE.Vector3();
const tmpA     = new THREE.Vector3();
const camOffset= new THREE.Vector3();

let throttle01     = 0.35;
let gSmooth        = 1.0;
let aoaDeg         = 0;
let dynPressurePa  = 0;
let machNumber     = 0;
let structuralStress = 0;
let rollAngle      = 0;     // actual bank angle
let flightAlive    = true;
let respawnGrace   = 0;
const clock = new THREE.Clock();

// ─────────────────────────────────────────────
//  DEBRIS
// ─────────────────────────────────────────────
const debrisMeshes = [];
const debrisGeo = new THREE.BoxGeometry(4,2,5);
const debrisMat = new THREE.MeshStandardMaterial({ color:0x3a4048, metalness:0.4, roughness:0.65 });

function clearDebris() {
  for (const m of debrisMeshes) scene.remove(m);
  debrisMeshes.length = 0;
}

function spawnDebris(at) {
  clearDebris();
  for (let i = 0; i < 24; i++) {
    const m = new THREE.Mesh(debrisGeo, debrisMat);
    m.position.copy(at).add(new THREE.Vector3(
      (Math.random()-0.5)*22, (Math.random()-0.5)*12, (Math.random()-0.5)*22
    ));
    m.rotation.set(Math.random()*6, Math.random()*6, Math.random()*6);
    m.userData.vel = new THREE.Vector3(
      (Math.random()-0.5)*120, 30+Math.random()*70, (Math.random()-0.5)*120
    );
    m.userData.av = new THREE.Vector3(
      (Math.random()-0.5)*5, (Math.random()-0.5)*5, (Math.random()-0.5)*5
    );
    scene.add(m);
    debrisMeshes.push(m);
  }
}

function crash(reason) {
  if (!flightAlive) return;
  flightAlive = false;
  throttle01  = 0;
  spawnDebris(plane.position);
  plane.visible = false;
  elCrash.textContent = `⚠ Kaza: ${reason}. Piste dönmek için F tuşuna bas.`;
  elCrash.classList.add("visible");
}

function respawnAtNearestRunway() {
  if (flightAlive) return;
  let best=RUNWAYS[0], bestD=Infinity;
  for (const rw of RUNWAYS) {
    const d = Math.hypot(plane.position.x-rw.cx, plane.position.z-rw.cz);
    if (d < bestD) { bestD=d; best=rw; }
  }
  if (!best) return;
  clearDebris();
  flightAlive = true;
  plane.visible = true;
  const terr = terrainHeight(best.cx, best.cz);
  const startAlong = -best.halfL*0.55;
  plane.position.set(
    best.cx + Math.sin(best.yaw)*startAlong,
    Math.max(terr, GROUND_Y)+20,
    best.cz + Math.cos(best.yaw)*startAlong
  );
  plane.rotation.set(0, best.yaw, 0);
  velocity.set(Math.sin(best.yaw)*80, 0, -Math.cos(best.yaw)*80);
  throttle01 = 0.50; gSmooth = 1; structuralStress = 0;
  respawnGrace = 3.0;
  orbitTheta = 0.6; orbitPhi = Math.PI*0.36; orbitRadius = 145;
  elCrash.classList.remove("visible");
}

// ─────────────────────────────────────────────
//  FLIGHT PHYSICS  (high-fidelity 6-DOF model)
// ─────────────────────────────────────────────
function updateFlight(dt) {
  if (!flightAlive) {
    for (const m of debrisMeshes) {
      m.position.addScaledVector(m.userData.vel, dt);
      m.userData.vel.y -= GRAVITY*dt;
      m.rotation.x += m.userData.av.x*dt;
      m.rotation.y += m.userData.av.y*dt;
      m.rotation.z += m.userData.av.z*dt;
    }
    return;
  }

  const alt = plane.position.y - GROUND_Y;
  const rho = airDensity(alt);
  const sos = speedOfSound(alt);

  // ── Throttle & Thrust ──────────────────────
  const throttleRate = 0.22;
  if (keys.w) throttle01 = Math.min(1, throttle01 + throttleRate*dt);
  if (keys.s) throttle01 = Math.max(0, throttle01 - throttleRate*0.85*dt);

  // AB kicks in above 85% throttle
  const abOn = throttle01 > 0.85;
  const thrustN = abOn
    ? THREE.MathUtils.lerp(THRUST_MAX_DRY, THRUST_MAX_AB, (throttle01-0.85)/0.15)
    : THREE.MathUtils.lerp(THRUST_MIN, THRUST_MAX_DRY, throttle01/0.85);

  // ── Control inputs → angular rates ────────
  // Pitch: Arrow keys
  // Roll: Q/E or A/D (A/D also yaw)
  // Yaw: coupled with roll (adverse/proverse yaw)
  const pitchCmd = (keys.ArrowUp   ? 1:0) - (keys.ArrowDown ? 1:0);
  const rollCmd  = (keys.e ? 1:0) - (keys.q ? 1:0)
                 + (keys.d ? 0.5:0) - (keys.a ? 0.5:0);  // A/D partially rolls
  const yawCmd   = (keys.d ? 1:0) - (keys.a ? 1:0);

  // Control effectiveness scales with dynamic pressure (q)
  const spd = velocity.length();
  machNumber = spd / sos;
  dynPressurePa = 0.5 * rho * spd * spd;
  const qNorm = Math.min(1.0, dynPressurePa / 40000); // effectiveness ramp

  // Apply rotations
  plane.rotation.x += pitchCmd * PITCH_RATE * qNorm * dt;
  const maxPitch = Math.PI/2 - 0.04;
  plane.rotation.x = THREE.MathUtils.clamp(plane.rotation.x, -maxPitch, maxPitch);

  // Roll
  rollAngle += rollCmd * ROLL_RATE * qNorm * dt;
  plane.rotation.z = THREE.MathUtils.lerp(
    plane.rotation.z,
    -rollAngle * 0.9,
    1 - Math.exp(-4 * dt)
  );

  // Yaw with adverse yaw coupling (realistic)
  const adverseYaw = -rollCmd * 0.15 * qNorm;
  plane.rotation.y += (yawCmd * YAW_RATE + adverseYaw) * qNorm * dt;

  // ── Aerodynamic force calculation ─────────
  plane.getWorldDirection(tmpFwd);
  noseDir.copy(tmpFwd).negate();        // aircraft forward = -Z in local space
  upDir.set(0,1,0).applyQuaternion(plane.quaternion); // aircraft up vector

  prevVel.copy(velocity);

  // Relative wind = velocity - ambient wind
  relWind.copy(velocity).sub(WIND);
  const V = relWind.length();

  if (V > 0.05) relN.copy(relWind).divideScalar(V);
  else relN.set(0,0,0);

  // Angle of Attack
  let aoa = 0;
  if (V > 1) {
    const cosA = THREE.MathUtils.clamp(noseDir.dot(relN), -1, 1);
    aoa = Math.acos(cosA);
    // Post-stall lift degradation
    if (aoa > AOA_STALL_RAD) {
      aoa = AOA_STALL_RAD + (aoa - AOA_STALL_RAD) * 0.08;
    }
  }
  aoaDeg = aoa * 180 / Math.PI;

  // Sideslip angle (for lateral forces & rudder effectiveness)
  const rightDir = new THREE.Vector3().crossVectors(noseDir, upDir).normalize();
  const sideslip = V > 1 ? relN.dot(rightDir) : 0;

  // CL (lift coefficient) — based on AoA
  const stallFactor = THREE.MathUtils.smoothstep(V, 28, 55); // stall below 28 m/s
  const CL = Math.min(CL_MAX, CL_ALPHA * Math.sin(aoa * 2)) * stallFactor;

  // CD (drag coefficient) — polar equation: CD = CD0 + K*CL²
  const CD = CD0
    + K_IND * CL * CL
    + 0.08 * Math.abs(sideslip)           // sideslip drag
    + (machNumber > 0.95 ? (machNumber-0.95)*0.8 : 0) // wave drag transonic
    + (keys.s ? 0.12 : 0);                // airbrake drag

  const q     = dynPressurePa;
  const liftN = CL * q * WING_AREA;
  const dragN = CD * q * WING_AREA;

  accel.set(0,0,0);

  // Thrust along nose direction
  accel.addScaledVector(noseDir, thrustN / AIRCRAFT_MASS);

  // Gravity
  accel.y -= GRAVITY;

  if (V > 0.4) {
    // Drag — opposing relative wind
    accel.addScaledVector(relN, -dragN / AIRCRAFT_MASS);

    // Lift — perpendicular to relative wind, in the plane's up-plane
    sideDir.crossVectors(noseDir, relN);
    if (sideDir.lengthSq() > 1e-10) {
      sideDir.normalize();
      liftDir.crossVectors(relN, sideDir).normalize();
      accel.addScaledVector(liftDir, liftN / AIRCRAFT_MASS);
    }

    // Sideslip restoring force (dihedral effect)
    accel.addScaledVector(rightDir, -sideslip * SIDESLIP_DAMP);
  }

  velocity.addScaledVector(accel, dt);

  // Speed of sound dependent max (no hard cap — drag naturally limits)
  // But cap at ~Mach 2.25 (F-22 Vmax)
  const spdMax = 2.25 * sos;
  const spdNow = velocity.length();
  if (spdNow > spdMax) velocity.multiplyScalar(spdMax / spdNow);

  plane.position.addScaledVector(velocity, dt);

  // ── G-force computation ───────────────────
  tmpA.copy(velocity).sub(prevVel).divideScalar(Math.max(dt, 1e-4));
  const gInst = tmpA.length() / GRAVITY;
  gSmooth = THREE.MathUtils.lerp(gSmooth, gInst, 1 - Math.exp(-10*dt));

  // ── Collision detection ───────────────────
  if (respawnGrace > 0) { respawnGrace -= dt; }

  const px=plane.position.x, py=plane.position.y, pz=plane.position.z;
  const tH = terrainHeight(px, pz);
  const onRw = pointOnRunway(px, py, pz);

  if (respawnGrace <= 0) {
    if (!onRw && py < tH + PLANE_CLEARANCE) { crash("Arazi çarpışması"); return; }
    if (boxHit(px, py, pz)) { crash("Bina çarpışması"); return; }
  }

  // ── Structural stress model ───────────────
  let stressIn = 0;
  if (gInst > G_STRESS_HARD)       stressIn += (gInst-G_STRESS_HARD)*STRESS_BUILD_H;
  else if (gInst > G_STRESS_SOFT)  stressIn += (gInst-G_STRESS_SOFT)*STRESS_BUILD_S;

  const qN = dynPressurePa/Q_LIMIT_PA;
  const aN = aoaDeg/Math.max(AOA_BREAK_DEG,1);
  if (qN > 0.8 && aN > 0.8) stressIn += (qN-0.8)*(aN-0.8)*180;
  if (dynPressurePa > Q_LIMIT_PA*1.05)
    stressIn += ((dynPressurePa-Q_LIMIT_PA*1.05)/(Q_LIMIT_PA*0.4))*16;

  const safeAero = gInst < 6.0 && dynPressurePa < Q_LIMIT_PA*0.65 && aoaDeg < 28;
  if (safeAero) structuralStress -= STRESS_DECAY*dt;
  else if (stressIn < 0.4 && gInst < G_STRESS_SOFT) structuralStress -= STRESS_DECAY*0.4*dt;
  structuralStress += stressIn*dt;
  structuralStress = THREE.MathUtils.clamp(structuralStress, 0, 100);

  if (structuralStress >= 99.5) { crash("Yapısal hasar — G/basınç/AoA aşımı"); return; }

  // Landing gear / runway ground contact
  if (onRw && py < tH+5) {
    plane.position.y = tH+6;
    if (velocity.y < -4) velocity.y *= -0.15;
    velocity.x *= 0.97; velocity.z *= 0.97; // rolling friction
  }

  // ── Control surface animations ────────────
  const ud = plane.userData;
  const now = performance.now()*0.001;
  const lr = 1 - Math.exp(-10*dt);

  if (ud.ctrl) {
    const pitchDef = pitchCmd * 0.42 + (rollAngle % (Math.PI*2)) * 0.10;
    const rollDiff  = rollCmd * 0.30;
    ud.ctrl.stabL.children[0].rotation.x = THREE.MathUtils.lerp(
      ud.ctrl.stabL.children[0].rotation.x, -(pitchDef + rollDiff), lr
    );
    ud.ctrl.stabR.children[0].rotation.x = THREE.MathUtils.lerp(
      ud.ctrl.stabR.children[0].rotation.x, -(pitchDef - rollDiff), lr
    );
  }

  // ── Engine effects ────────────────────────
  const heat = throttle01 * throttle01;
  const abBoost = abOn ? 0.7 : 0.0;
  const shimmer = 0.85 + 0.15*Math.sin(now*42) + 0.07*Math.sin(now*77);
  const nozInt  = heat*2.4*shimmer + abBoost;

  if (ud.nozzles) {
    ud.nozzles.forEach(n => {
      n.material.emissiveIntensity = nozInt;
      const t = THREE.MathUtils.clamp(heat, 0, 1);
      n.material.emissive.setRGB(1.0, 0.08+0.35*t, 0.0);
    });
  }
  if (ud.glows) {
    ud.glows.forEach((g, i) => {
      const freq  = i%2===0 ? 31 : 19;
      const flick = 0.78 + 0.22*Math.sin(now*freq);
      const base  = i<2 ? 0.82 : 0.45;
      g.material.opacity = (heat*base + abBoost*0.55) * flick;
    });
  }

  // ── Vapor cone effect ─────────────────────
  const vaporG = Math.max(0, gSmooth-2.0);
  const vaporV = THREE.MathUtils.smoothstep(spd, 50, 140);
  const pitching = (keys.ArrowUp||keys.ArrowDown) ? 1:0;
  const vaporA = Math.min(0.65,
    vaporG*0.12*vaporV
    + pitching*0.12*vaporV
    + Math.max(0,aoaDeg-7)*0.010*vaporV
    + (machNumber>0.92 ? (machNumber-0.92)*0.4*vaporV : 0)
  );
  if (ud.vapor) {
    ud.vapor.forEach(m => {
      m.material.opacity = vaporA*(0.80+0.20*Math.sin(now*5.2));
    });
  }

  // ── Dynamic sky color with altitude ───────
  const t_alt = THREE.MathUtils.clamp(alt/12000, 0, 1);
  const skyColor = new THREE.Color().lerpColors(
    new THREE.Color(0x7bbce8),  // low alt: lighter blue
    new THREE.Color(0x0a1a3a),  // high alt: dark space blue
    t_alt*t_alt
  );
  scene.background = skyColor;
  scene.fog.color.copy(skyColor).lerp(new THREE.Color(0xaaccee), 0.4);
}

// ─────────────────────────────────────────────
//  CAMERA
// ─────────────────────────────────────────────
function updateCamera(dt) {
  const target = plane.position;
  camOffset.set(
    orbitRadius * Math.sin(orbitPhi)*Math.sin(orbitTheta),
    orbitRadius * Math.cos(orbitPhi),
    orbitRadius * Math.sin(orbitPhi)*Math.cos(orbitTheta)
  );
  camPos.copy(target).add(camOffset);
  camera.position.lerp(camPos, 1-Math.exp(-7*dt));
  camera.lookAt(target);
}

// ─────────────────────────────────────────────
//  HUD
// ─────────────────────────────────────────────
function hud() {
  if (!flightAlive) {
    elGWarn.classList.remove("visible");
    elSpeed.textContent = "—";
    elStress.textContent = "—";
    if (elMach) elMach.textContent = "—";
    return;
  }

  elStress.textContent = Math.round(structuralStress);
  if (elMach) elMach.textContent = machNumber.toFixed(2);
  if (elThrottle) elThrottle.textContent = Math.round(throttle01*100);
  if (elRoll) elRoll.textContent = Math.round(rollAngle * 180 / Math.PI % 360);

  if (gSmooth > G_WARN || structuralStress > 62) {
    const parts = [];
    if (gSmooth > G_WARN) parts.push(`G ${gSmooth.toFixed(1)}`);
    if (structuralStress > 62) parts.push(`Yapı %${Math.round(structuralStress)}`);
    elGWarn.textContent = `⚠ UYARI — ${parts.join(" · ")}`;
    elGWarn.classList.add("visible");
  } else {
    elGWarn.classList.remove("visible");
    elGWarn.textContent = "";
  }

  const spd = velocity.length();
  elSpeed.textContent   = Math.round(spd*3.6);
  elAlt.textContent     = Math.round(plane.position.y - GROUND_Y);
  elPitch.textContent   = Math.round(-plane.rotation.x*180/Math.PI);
  let h = -plane.rotation.y*180/Math.PI;
  while(h<0) h+=360; while(h>=360) h-=360;
  elHeading.textContent = Math.round(h);
  elG.textContent       = gSmooth.toFixed(1);
  elAoA.textContent     = Math.round(aoaDeg);
  elDynPress.textContent= Math.round(dynPressurePa/1000);
  const w = WIND.length();
  elWind.textContent    = `${Math.round(w*3.6)} @ ${Math.round((Math.atan2(WIND.x,WIND.z)*180/Math.PI+180))}°`;
}

// ─────────────────────────────────────────────
//  MAIN LOOP
// ─────────────────────────────────────────────
function tick() {
  const dt = Math.min(clock.getDelta(), 0.05);
  updateFlight(dt);
  updateCamera(dt);
  hud();
  renderer.render(scene, camera);
  requestAnimationFrame(tick);
}

addEventListener("resize", () => {
  camera.aspect = innerWidth/innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

tick();
